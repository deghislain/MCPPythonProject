from stock_tools import StockTools as tools
import streamlit as st

if __name__ == "__main__":
    stock_symbol = st.text_input(":blue[Stock Symbol]")
    st.button("submit")
    if stock_symbol:
        print(tools.get_income_statement_info(stock_symbol))
